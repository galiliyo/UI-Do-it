export interface Todo {
  todo: string;
  isDone: boolean;
  id?: number;
}
