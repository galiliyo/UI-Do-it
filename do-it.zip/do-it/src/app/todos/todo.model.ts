export class Todo {
  constructor(public todo:string,public isDone:boolean) {
  }
}
